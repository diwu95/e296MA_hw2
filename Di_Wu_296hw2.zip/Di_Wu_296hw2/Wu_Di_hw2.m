%makedist, mean, median, iqr, var, std, pdf, random 

%% 2 b (i) 
%Use makedist to create an exponential distribution object. Set the mean (?) to 100.
eD=makedist('Exponential','mu',100)

%% 2 b (ii) 
%What is the formula for the probability density function of this distribution?

%The formula of pdf of exponetial function is 1/mu*exp(-x/mu)

%% 2 b (iii)
%Use Matlab to find its mean, median, interquartile range, variance, and standard deviation.
meanED=mean(eD); medianED=median(eD); iqrED=iqr(eD);varED=var(eD); stdED=std(eD);

%% 2 b (iv) 
%Use Matlab?s random to generate data sets sampled from this distribution. Create
%three data sets with 2, 10, and 1000 samples each.
set2=random(eD,[2,1]);set10=random(eD,[10,1]);set1k=random(eD,[1000,1]);

%% 2 b (v)
% Use histogram to plot a histogram for the data set with 1000 samples. Overlay this
% histogram with the pdf (Use linspace and pdf).
% Hint: histogram(data,?Normailization?,?pdf?)
figure(1)
histogram(set1k,'Normalization','pdf')
hold on
x=linspace(0,1000);
pdf1k=pdf(eD,x);
plot(x,pdf1k)

%% 2 b (vi)
% Now use random to generate three matrices of samples; one 2�1000, another 10�1000,
% and another 1000�1000.
mat2x1k=random(eD,[2,1000]);mat10x1k=random(eD,[10,1000]);mat1kx1k=random(eD,[1000,1000]);


%% 2 b (vii)
% Compute the sample means. You will get three arrays of size 1�1000 corresponding
% to averages of samples of size 2, 10, and 1000.
meanMat2x1k=mean(mat2x1k); meanMat10x1k=mean(mat10x1k); meanMat1kx1k=mean(mat1kx1k);

%% 2 b (viii)
% Plot histograms of each of these arrays of sample means. Overlay the histograms
% with a Gaussian fit. Hint: histfit.
figure(2)
histfit1=histfit(meanMat2x1k,1000,'normal')
 figure(3)
histfit1=histfit(meanMat10x1k,1000,'normal')
 figure(4)
histfit1=histfit(meanMat1kx1k,1000,'normal')


%% 2 b (ix)
% How does this result relate to the Central Limit Theorem?

%According to the central limit theorem,
%when independent random variables are added, their properly normalized sum 
%tends toward a normal distribution (a bell curve) even if the original variables
%themselves are not normally distributed.

%As shown in part viii, all three histograms can be fitted by normal
%distribtion. These three histgrams are plotted with the mean of data randomly drawn 
%from the exponential distributed set in part i. The mean of a function is
%the addition of each term in the set divided by the number of term. This
%is related to "independent random variables are added". Because the origianl
%data set are exponetial distributated, this is related to "the original variables
%themselves are not normally distributed". Also, these three histgrams can
%be fitted with normal distribution. This is related to 'their properly normalized sum 
%tends toward a normal distribution (a bell curve)'. Thus, the result
%follows the Central Limit Theorem. 



